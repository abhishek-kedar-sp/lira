console.log('my service worked');
// chrome.alarms.onAlarm.
chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
	if (changeInfo.url) {
		console.log('tab navigated to', changeInfo.url)
	}
	// chrome.tabs.getCurrent().then(function(tab) {
	// 	console.log(tab);
	// })
	
})
chrome.webNavigation.onCompleted.addListener(function (details) {
	console.log('webNavigation completed navigated to', details)
}, { url: [{ hostEquals: 'www.github.com' }] })